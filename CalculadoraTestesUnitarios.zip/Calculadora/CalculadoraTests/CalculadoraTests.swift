import XCTest
@testable import Calculadora

class CalculadoraTests: XCTestCase {

    let calculadora = ContentView()

    func testSomarDoisNumerosPositivos() {
        let resultado = calculadora.sum(num1: 5, num2: 7)
        XCTAssertEqual(resultado, 12)
    }

    func testSomarComNil() {
        let resultado = calculadora.sum(num1: nil, num2: 7)
        XCTAssertNil(resultado)
    }

    func testSomarNegativos() {
        let resultado = calculadora.sum(num1: -5, num2: -3)
        XCTAssertEqual(resultado, -8)
    }

    func testSubtrairDoisNumeros() {
        let resultado = calculadora.subtract(num1: 10, num2: 3)
        XCTAssertEqual(resultado, 7)
    }

    func testSubtrairComNil() {
        let resultado = calculadora.subtract(num1: 10, num2: nil)
        XCTAssertNil(resultado)
    }

    func testSubtrairNegativo() {
        let resultado = calculadora.subtract(num1: -4, num2: -6)
        XCTAssertEqual(resultado, 2)
    }

    func testMultiplicarDoisNumeros() {
        let resultado = calculadora.multiply(num1: 4, num2: 3)
        XCTAssertEqual(resultado, 12)
    }

    func testMultiplicarComNil() {
        let resultado = calculadora.multiply(num1: nil, num2: 3)
        XCTAssertNil(resultado)
    }

    func testMultiplicarPorZero() {
        let resultado = calculadora.multiply(num1: 10, num2: 0)
        XCTAssertEqual(resultado, 0)
    }

    func testDividirDoisNumeros() {
        let resultado = calculadora.divide(num1: 10, num2: 2)
        XCTAssertEqual(resultado, 5)
    }

    func testDividirPorZero() {
        let resultado = calculadora.divide(num1: 10, num2: 0)
        XCTAssertNil(resultado)
    }

    func testDividirComNil() {
        let resultado = calculadora.divide(num1: nil, num2: 2)
        XCTAssertNil(resultado)
    }
}

