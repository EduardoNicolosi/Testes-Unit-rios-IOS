//
//  CalculadoraApp.swift
//  Calculadora
//
//  Created by Mark Joselli on 06/05/25.
//

import SwiftUI

@main
struct CalculadoraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
